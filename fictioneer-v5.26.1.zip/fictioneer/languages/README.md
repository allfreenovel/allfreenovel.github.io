Due to their large size, all .PO translation files are removed from the release versions but still available in the [GitHub repository](https://github.com/Tetrakern/fictioneer/tree/main/languages).
